const sumar = function(a,b){
    return a + b
}
const restar = function (a,b){
    return a - b
}
const multiplicar = function (a,b){
    return a * b
}
const dividir = function (a,b){
    return a / b
}
const potencia = function (a,b){
    return a ** b
}

module.exports = {
    sumar,restar,dividir,multiplicar,potencia
}